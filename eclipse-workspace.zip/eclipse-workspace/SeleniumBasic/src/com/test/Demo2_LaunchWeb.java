// id = NoSuchElementException 
// name = WebDriver will fetch the first matching element
//ClassName = class



package com.test;

import java.util.Iterator;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class Demo2_LaunchWeb {

	WebDriver driver;
	String url ="https://www.google.co.in/";

	@Before
	public void before() {

		System.setProperty("webdriver.gecko.driver","D:\\CucumberJarFiles\\geckodriver-FireFox\\geckodriver.exe");
		driver = new FirefoxDriver();

		driver.manage().window().maximize();		

		//		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver_win32\\chromedriver.exe");
		//	driver = new ChromeDriver();

		driver.manage().window().maximize();			
		driver.get(url);		
	}

	@Test
	public void test() {
		String pageTitle = driver.getTitle();
		System.out.println("Page title: " + pageTitle);
	}

	@After
	public void after() {


		String parent_window = driver.getWindowHandle();

		Set<String> s1 = driver.getWindowHandles();
		Iterator<String> i1 = s1.iterator();

		while(i1.hasNext()) {
			String child_Window = i1.next();


			if(!parent_window.equalsIgnoreCase(child_Window))
			{
				driver.switchTo().window(child_Window);
				driver.getTitle();

			}


		}


		driver.close();
	}
}	