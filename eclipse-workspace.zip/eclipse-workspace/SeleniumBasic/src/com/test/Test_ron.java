package com.test;

import java.util.Scanner;

import javax.jws.WebParam.Mode;

import org.junit.Assert;

import com.google.common.base.Verify;

public class Test_ron {

	public static void main(String[] args) {


	
		String abcd = "#(*$&$#My name is Ronak#$%&)*";
		StringBuilder abc = new StringBuilder(abcd);
		String reverseString = abc.reverse().toString();

		reverseString=reverseString.toUpperCase();
		System.out.println(reverseString);

		int count =0;
		for (int i = 0; i < reverseString.length(); i++) {

			if(reverseString.charAt(i)=='A') {
				count++;
			}
		}

		System.out.println(count++);

		String reverseString2 = reverseString.replaceAll("\\s+", "");
		System.out.println("Replace String "+reverseString2 );


		count =0;
		reverseString = reverseString.replaceAll("[^a-zA-Z0-9]", " ");
		reverseString = reverseString.trim();

		System.out.println(reverseString);
		String[] reverseString3 = reverseString.split("\\s+");

		for (int i = 0; i < reverseString3.length; i++) {

			System.out.println(reverseString3[i]);
			if(reverseString3[i].equalsIgnoreCase("KANOR")) {
				count++;
			}
		}

		System.out.println(count++);

		//Scanner input = new Scanner(System.in);
		//String abcdef = input.nextLine();

		//System.out.println(abcdef);


		System.out.println("   ");
		System.out.println("   ");
		int n = 10;

		int i1 = 0;
		int i2 = 1;
		int i3 = 0;
		for (int i = 0; i < n; i++) {

			System.out.print(" ");
			System.out.print(i1);

			i3 = i1 +i2;

			i1 = i2;
			i2 = i3;


		}


		System.out.println("Hello World");
		int[] mcq = new int[] {10,20,30,40,50};

		int a[] = {1,2,3,4,5};

		int ac[] = new int[5];

		for (int i = a.length-1; i >= 0; i--) {

			System.out.print(a[i]);

			ac[i]=a[i];

			//if (a[i] % 2 == 0 ) {
			//	System.out.println("Even Number " +a[i]);
			//}

		}



	}
}



