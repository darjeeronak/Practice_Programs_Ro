package com.Ronak;

public class Practice_Ron {

	public static void main(String[] args) {

		String abc = "My Name is Ronak";

		//abc = abc.toUpperCase();

		StringBuilder xyz = new StringBuilder(abc);
		String cba = xyz.reverse().toString();
		System.out.println("1: "+cba);
		System.out.println();


		String trimvalue = cba.replaceAll("\\s", "");
		trimvalue = trimvalue.toLowerCase();
		System.out.println(trimvalue);

		String ron = "$Ronak *is #a g00d b@y";
		ron = ron.replaceAll("[^a-zA-Z0-9]", "");

		System.out.println("---------------------------------------------");
		System.out.println(ron);
		System.out.println("---------------------------------------------");

		System.out.println(ron.replaceAll("\\s", ""));

		char b;
		int count =0;
		for(int i = 0; i <ron.length();i++) {
			b = ron.charAt(i);
			Character.isLowerCase(b);

			if(b == 'a') {
				count++;
			}

		}
		System.out.println("Occurance of a is : "+count);


		String LineRonak ="Hello  Ronak  Ronak Here I hope you are not ronak Count ronak";

		String b1[] = LineRonak.split("\\s+");

		int count1 =0;
		for (int i = 0; i < b1.length; i++) {
			if(b1[i].equalsIgnoreCase("ronak")) {
				count1++;
			}
		}
		System.out.println("Occurance of word "+ "ronak " + "is: "+count1++);



		String a[] = LineRonak.split("\\s+");
		int c = a.length;
		System.out.println(c);

		for (int i = 0; i < c; i++) {

			if(a[i].equalsIgnoreCase("ronak")) {
				System.out.println("Ronak here");
			}
		}





	}
}
