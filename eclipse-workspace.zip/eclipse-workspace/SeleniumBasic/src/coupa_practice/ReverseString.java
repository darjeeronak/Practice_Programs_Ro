package coupa_practice;

public class ReverseString {


	public static void main(String[] args) {


		String abc = "Hello my name is Ronak";
		StringBuilder reversevar = new StringBuilder(abc);
		String reversestring = reversevar.reverse().toString();

		//System.out.println(reversestring);


		String str = "a!!!b.c.d,e'f,ghi"; 
		char[] charArray = str.toCharArray(); 

		System.out.println("Input string: " + str); 

		String revStr = new String(charArray); 

		System.out.println("Output string: " + revStr); 

	}
}
