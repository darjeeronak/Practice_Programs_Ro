package coupa_practice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;



public class Edgebrowser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		System.setProperty("webdriver.edge.driver", "C:\\Users\\Ronak_Darjee\\Downloads\\Browser Properties\\edgedriver_win64\\msedgedriver.exe");
		WebDriver driver = new EdgeDriver();
		driver.get("https://www.google.co.in/");
		driver.close();
		 */


		/*
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Ronak_Darjee\\Downloads\\Browser Properties\\chromedriver_win32\\chromedriver.exe");
		ChromeDriver chrome;
		chrome = new ChromeDriver();
		chrome.navigate().to("https://www.google.co.in/");
		chrome.close();
		 */

		/*
		System.setProperty("webdriver.ie.driver","C:\\Users\\Ronak_Darjee\\Downloads\\Browser Properties\\IEDriverServer_Win32_3.150.1\\IEDriverServer.exe");
		WebDriver driver = new  InternetExplorerDriver();
		driver.navigate().to("https://www.google.co.in/");
		driver.close();
		 */

		/*
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\Ronak_Darjee\\Downloads\\Browser Properties\\geckodriver-v0.28.0-win64\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.navigate().to("https://www.google.co.in/");
		System.out.println(driver.getTitle());
		driver.close();
		 */


		//we are creating object for chromedriver class;
		//WebDriver = interface
		// driver = local variable - saving instance in variable to perform an action
		// new = to create object of class
		//ChromeDriver() = constructor; [ constructorname = classname]


		//interface WebDriver extends SearchContext
		//WebDriver driver = new ChromeDriver(); [ extends remotewebdriver]
		//ChromeDriver driver2 = new ChromeDriver();


		//chromiumDriver extends RemoteWebDdriver implements WebDriver extends SearchContext

	}

}