package StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RonakisTesting {

	WebDriver driver;

	@Given("^I am opening firefox and launching my application$")
	public void i_am_opening_firefox_and_launching_my_application() throws Throwable {

		//System.setProperty("webdriver.ie.driver","C:\\Users\\Ronak_Darjee\\Downloads\\Browser Properties\\IEDriverServer_Win32_3.150.1\\IEDriverServer.exe");
		//driver = new  InternetExplorerDriver();

		System.setProperty("webdriver.edge.driver", "C:\\Users\\Ronak_Darjee\\Downloads\\Browser Properties\\edgedriver_win64\\msedgedriver.exe");
		driver = new EdgeDriver();

		//System.setProperty("webdriver.gecko.driver", "C:\\Users\\Ronak_Darjee\\Downloads\\Browser Properties\\geckodriver-v0.28.0-win64\\geckodriver.exe");					
		//driver= new FirefoxDriver();					
		driver.manage().window().maximize();	
		driver.navigate().to("http://demowebshop.tricentis.com/login");


	}


	@When("^I enter Username \"(.*?)\" and Password \"(.*?)\" in application$")
	public void i_enter_Username_and_Password_in_application(String arg1, String arg2) throws Throwable {

		System.out.println(arg1);
		System.out.println(arg2);

		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Password")));

		driver.findElement(By.id("Email")).sendKeys(arg1);		
		//driver.wait(5000);
		driver.findElement(By.id("Password")).sendKeys(arg2);	

	}



	@Then("^I should login successfully$")
	public void i_should_login_successfully() throws Throwable {

		//driver.wait(5000);
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		//driver.wait(5000);
		driver.close();
	}



}
