package AllLocators;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class practicelocator {



	public static void main(String[] args) {

		//System.setProperty("webdriver.ie.driver", "D:\\CucumberJarFiles\\IEDriverServer_x64_3.150.1\\IEDriverServer.exe");
		System.setProperty("webdriver.gecko.driver", "D:/CucumberJarFiles/geckodriver-FireFox/geckodriver.exe");

		WebDriver driver;
		//driver=new InternetExplorerDriver();
		driver= new FirefoxDriver();

		driver.manage().window().maximize();
		//driver.manage().deleteAllCookies();

		driver.get("https://www.goibibo.com/");

		WebDriverWait wait = new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("gosuggest_inputDest")));
		System.out.println(" ");
		WebElement IDElement1 = driver.findElement(By .id("gosuggest_inputDest"));

		if (IDElement1.isEnabled()) {
			System.out.println("1: ID:"+IDElement1); }
		else {
			System.out.println("1: ID: Absent");}

		/*WebElement IDElement2 = driver.findElement(By .name("k"));
		if (IDElement2.isEnabled()) {
			System.out.println("1: Name:"+IDElement2); }
		else {
			System.out.println("1: Name: Absent");} */

		WebElement IDElement3 = driver.findElement(By .className("inputSrch"));
		if (IDElement3.isEnabled()) {
			System.out.println("3: Class:"+IDElement3); }
		else {
			System.out.println("3: Class: Absent");}

		WebElement IDElement4 = driver.findElement(By .linkText("About Us"));
		if (IDElement4.isEnabled()) {
			System.out.println("4: LinkText:"+IDElement4); }
		else {
			System.out.println("4: LinkText: Absent");}


		WebElement IDElement5 = driver.findElement(By .partialLinkText("About"));
		if (IDElement5.isEnabled()) {
			System.out.println("5: PartialLinkText:"+IDElement5); }
		else {
			System.out.println("5: PartialLinkText: Absent");}

		WebElement IDElement6 = driver.findElement(By .xpath("//*[@id=\"footer\"]/div[2]/div[1]/ul[2]/li[2]/a"));
		if (IDElement6.isEnabled()) {
			System.out.println("6: Xpath:"+IDElement6); }
		else {
			System.out.println("6: Xpath: Absent");}


		//*[contains(@id,"gosuggest_inputDest")]
		//input[@id="gosuggest_inputDest" or @placeholder="Destination"]



		//xpath
		WebElement IDElement6A = driver.findElement(By .xpath("//input[@id=\"gosuggest_inputDest\" and @placeholder=\"Destination\"]"));
		if (IDElement6A.isEnabled()) {
			System.out.println("6A: Xpath:"+IDElement6A); }
		else {
			System.out.println("6A: Xpath: Absent");}

		//TAG+ID
		System.out.println("7A: CSS TAG+ID: "+driver.findElement(By .cssSelector("input#gosuggest_inputDest")));

		//Tag+Class
		System.out.println("7B: CSS TAG+CLASS: "+driver.findElement(By .cssSelector("input.inputSrch")));


		//Tag+Attribute
		System.out.println("7C: CSS TAG+ATTRIBUTE: "+driver.findElement(By .cssSelector("input[id=gosuggest_inputDest]")));


		//Tag+CLASS+Attribute
		System.out.println("7D: CSS TAG+CLASS+ATTRIBUTE "+driver.findElement(By .cssSelector("input.inputSrch[id=gosuggest_inputDest]")));


		//System.out.println(driver.findElement(By .tagName("a")).getText());

		System.out.println("");

		List<WebElement> abc = driver.findElements(By .tagName("a"));
		for(WebElement i :abc) {
			String name = i.getText();
			System.out.println(name);
		}

		//System.out.println(driver.findElement(By .name("a")).getText());

		driver.close();
	}
}