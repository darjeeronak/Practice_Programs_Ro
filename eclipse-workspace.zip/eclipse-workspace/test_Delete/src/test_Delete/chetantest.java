package test_Delete;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class chetantest {

	WebDriver driver;	

	@Given("^Open Tricentis WebPage$")
	public void open_Tricentis_WebPage() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.gecko.driver", "D://CucumberJarFiles//geckodriver-FireFox//geckodriver.exe");					
		driver= new FirefoxDriver();					
		driver.manage().window().maximize();			
		driver.get("http://demowebshop.tricentis.com/");	

	}

	@When("^Enter the Username and Password$")
	public void enter_the_Username_and_Password() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);

		driver.findElement(By .linkText("Log in")).click();

		driver.findElement(By .id("Email")).sendKeys("Hello@everyone.com");
		driver.findElement(By .id("Password")).sendKeys("password");

	}

	@Then("^Close the browser$")
	public void close_the_browser() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Thread.sleep(5000);
		driver.close();
	}
	

}
