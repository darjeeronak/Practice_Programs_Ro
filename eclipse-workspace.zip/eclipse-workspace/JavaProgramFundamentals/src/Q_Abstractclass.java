
public class Q_Abstractclass {
	public static void main(String[] args) {
	}
}


abstract class Vehicle{
	int no_of_types;

	abstract void start();
}


class Car extends Vehicle{

	void start(){
		System.out.println("Start with Key");
	}

}

class Scooter extends Vehicle{

	void start(){
		System.out.println("Start with kick");
	}


	public static void main(String[] args) {

		Vehicle c = new Car();
		c.start();

		Scooter s = new Scooter();
		s.start();
	}


}