
public class I_Inheritance1 {

	int tenure;
	double principal;
	float interestRate;
	String accountNo;

	public double calculateEMI(){
		double simpleInterest = (principal*interestRate*tenure)/100;
		double emi = (simpleInterest+principal)/tenure;
		return emi;
	}

}

class HomeLoan extends I_Inheritance1 {

	HomeLoan(){
		tenure = 5;  //reusing super class member variables
		principal = 20000;
		interestRate = 8.5f;
		accountNo = "Acc12345";
	}

	public static void main(String[] args) {
		HomeLoan hloan = new HomeLoan();
		double amount = hloan.calculateEMI();
		System.out.println("EMI per year is :"+amount);

	}


}