//Getter-Setter Concepts

public class b_Exercise1_Student {

	private int studentID;
	private String name;
	private float qualifyingExamMarks;
	private char residentialStatus;
	private int yearofEngg;

	public static void main(String[] args) {
		b_Exercise1_Student myObj1 = new b_Exercise1_Student();


		myObj1.setStudentID(1001);
		int a = myObj1.getStudentID();

		myObj1.setName("Jacob");
		String b = myObj1.getName();

		myObj1.setQualifyingExamMarks(80);
		float c = myObj1.getQualifyingExamMarks();

		myObj1.setResidentialStatus('H');
		char d = myObj1.getResidentialStatus();

		myObj1.setYearofEngg(3);;
		int e = myObj1.getYearofEngg();

		System.out.println("Student Name       :   "+b);
		System.out.println("Student Id         :   "+a);
		System.out.println("Qualifying marks   :   "+c);
		System.out.println("Year of Engineering:   "+e);
		System.out.println("Residential status :   "+d);

		System.out.println("");

		myObj1.setStudentID(1002);
		int a1 = myObj1.getStudentID();

		myObj1.setName("Peter");
		String b1 = myObj1.getName();

		myObj1.setQualifyingExamMarks(83);
		float c1 = myObj1.getQualifyingExamMarks();

		myObj1.setResidentialStatus('D');
		char d1 = myObj1.getResidentialStatus();

		myObj1.setYearofEngg(2);
		int e1 = myObj1.getYearofEngg();

		System.out.println("Student Name       :   "+b1);
		System.out.println("Student Id         :   "+a1);
		System.out.println("Qualifying marks   :   "+c1);
		System.out.println("Year of Engineering:   "+e1);
		System.out.println("Residential status :   "+d1);


	}

	public int getStudentID() {
		return studentID;
	}
	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public float getQualifyingExamMarks() {
		return qualifyingExamMarks;
	}
	public void setQualifyingExamMarks(float qualifyingExamMarks) {
		this.qualifyingExamMarks = qualifyingExamMarks;
	}

	public char getResidentialStatus() {
		return residentialStatus;
	}
	public void setResidentialStatus(char residentialStatus) {
		this.residentialStatus = residentialStatus;
	}

	public int getYearofEngg() {
		return yearofEngg;
	}
	public void setYearofEngg(int yearofEngg) {
		this.yearofEngg = yearofEngg;
	}
}