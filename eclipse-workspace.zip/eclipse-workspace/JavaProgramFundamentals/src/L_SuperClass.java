public class L_SuperClass {

	protected int tenure;
	protected float interestRate;

	L_SuperClass(int tenure, float interestRate){
		this.tenure = tenure;
		this.interestRate = interestRate;
	}

}


class HomeLoan_11 extends L_SuperClass{

	HomeLoan_11(){
		super(5,8.5f);  //invoking super class constructor
	}

	public double calculateEMI(double principal){
		double simpleInterest = (principal * interestRate * tenure) / 100;
		double emi = (simpleInterest + principal) / tenure;
		int additionalTax = 200;
		return emi + additionalTax;
	}

}


class Execution1{

	public static void main (String[] args) {
		HomeLoan_11 loan = new HomeLoan_11();
		double hloan = loan.calculateEMI(2000000);
		System.out.println("Home loan emi per year..." + hloan);
	}

}

////////////////////////////////////////////////////////////////////////////////





class Parent_Loan {

	public double calculateEMI(double principal) {
		double simpleInterest = (principal*8.5*5) / 100;
		double emi = (simpleInterest+principal)/5;
		return emi;
	}
}

class Child_HomeLoan extends Parent_Loan {
	
	public double calculateEMI(double principal) {
		int additionaltax = 200;
		double emi = super.calculateEMI(principal);     //calling super class method
		return emi + additionaltax;
	}
}


class Main_ExecuteLoan {
	public static void main(String[] args) {
		Parent_Loan loan = null;
		loan =  new Child_HomeLoan();                 // Runtime polymorphism
		double hloan = loan.calculateEMI(2000000);
		System.out.println("Home loan emi per year..."+ hloan);
	}
}





