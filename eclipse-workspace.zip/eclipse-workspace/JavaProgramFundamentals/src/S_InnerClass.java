class Outside{
	int a = 0;

	class Inside{
		int b = 5;
	}



	private class Grade{
		private char grade;

		private char calculateGrade(String employeeid, int point) {

			if (isEmployeeExists(employeeid))  {
				if (point  < 100 && point >= 90) {
					grade = 'A';
				} else if (point < 90 && point >= 80) {
					grade = 'B';
				} else {
					grade = 'C';
				}
			}

			return grade;
		}

		private boolean isEmployeeExists(String employeeId) {
			// check from database or file system
			return true;
		}

	}

	public char checkEmployeeID(String employeeId, int point) {
		Grade grade = new Grade();                                
		return grade.calculateGrade(employeeId,point);
	}

}


public class S_InnerClass {

	public static void main(String[] args) {
		Outside o = new Outside();
		Outside.Inside i = o.new Inside();

		System.out.println(o.a + " " + i.b);


		Outside manager = new Outside();

		String employeeId = "I1001";
		char gradePoint = manager.checkEmployeeID(employeeId, 80);
		System.out.println("the grade for " + employeeId + "is " + gradePoint);

		String abcd = "1234";
		int a = Integer.parseInt(abcd);



	}
	
	
}