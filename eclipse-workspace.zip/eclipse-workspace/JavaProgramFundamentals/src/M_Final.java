
public class M_Final {
	final int tenure = 0; //Value is made as final
	double principal;
	float interestRate;
	String accountNumber;


	public final  int calculateEMI(){ 
		//A final method cannot be overridden by subclasses.
		return 2000;
	}
}


class M_Final_1 extends M_Final{

	M_Final_1(){
		super.tenure = 10; //Value cannot be modified as the variable is final
	}


	double calculateEMI(){    //cannot be overridden
		return 2000;
	}
}

final class ronak{
	}

class chetan extends ronak{
	
}