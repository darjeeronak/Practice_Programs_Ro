import java.util.Scanner;

public class E_Loops {
	public static void main(String[] args) {


		//if statement
		double balance = 500;
		int amount = 500;


		if (amount < 500 && balance >= 500) {
			System.out.println("They are same");
		}
		else if (amount > 500 || balance >= 500 ) {
			System.out.println("They are different");
		}
		else {
			System.out.println("Dhoom");
		}

		/*
		Scanner sc= new Scanner(System.in);    //System.in is a standard input stream  
		System.out.print("Enter first number- ");  
		int a= sc.nextInt();  
		 */

		//
		int rank = 1;
		switch(rank) {

		case 0 :
			System.out.println("Case 0");
			break;

		case 1 :
			System.out.println("Case 1");
			break;
		case 2 :
			System.out.println("Case 2");
			break;
		default :
			System.out.println("No Case");
		}



		int vari = 100;

		do {
			System.out.println("Do-While Vari "+vari);
			vari = vari + 100;

		} while (vari < 500);



		vari=100;

		while (vari < 500)
		{
			System.out.println("While Vari "+vari);
			vari = vari + 100;
		}	



		int s = 500;
		int i;
		for (i=100 ; i<s ; i ++) {
			System.out.println("I:" +i);
		}


		double balance1 = 6000, rateOfInterest = 0.10, interest = 0;
		double withdrawal = 500, deposit = 600;
		System.out.println("\nOutput:\n");
		for(int i1 = 1; i1 <= 12; ++i1) {
			balance1 += deposit;
			balance1 -= withdrawal;
			interest = balance1 * rateOfInterest;
			balance1 += interest;
			System.out.println("The interest for the month " + i1 + " is " + interest);
		}
		System.out.println("The balance at the end of the year is " + balance1);



		int f =11;
		switch (f) { // Line 1
		case 10+1: 
			System.out.println("Twelve"); // Line 2
		case 0: 
			System.out.println("Zero"); //Line 3
		case (int)12.0: 
			System.out.println("Decimal"); 
		default: 
			System.out.println("Default");
		}



		int sum=0;
		for(int i1=0,j=0;i1<5&j<5;++i1,j=i1+1)
		{
			sum+=i1;
			System.out.println(sum);
		}



		String username ="John";
		String password ="Infy123";

		System.out.println("\nString Compare");		
		String str = (username.equals("John") && password.equals("Infy123")) ? "Welcome!": "Sorry";
		System.out.println(str);


		int sum1=0;
		for(int i1=0,j=0;i1<5&j<5;++i1,j=i1+1)
			sum1+=i1;

		System.out.println(sum1);


		System.out.println("\n---------------\n");	
		//Reverse the string

		/*
		Scanner abcd = new Scanner(System.in);
		System.out.println("Enter a string: ");
		String beforeString = abcd.nextLine();


		StringBuilder abc = new StringBuilder(beforeString);
		String afterString = abc.reverse().toString();

		System.out.println(beforeString);
		System.out.println(afterString);

		 */
		int numberToReverse = 12345;
		System.out.println(numberToReverse);

		int  reminder =0;
		int reveresedNo = 0;


		while( numberToReverse != 0 ) {

			reminder = numberToReverse % 10;
			reveresedNo = reveresedNo * 10 + reminder;
			numberToReverse = numberToReverse/10;

		}


		System.out.println(reveresedNo);





		/*


		double balance1 = 0, minbal = 500, depositAmt1 = 0;
		Scanner sc1 = new Scanner(System.in);    //Scanner class is used to accept input from the keyboard.
		do {      // do-while executes once vefore the condition is tested, then repeats till the condition is satisfied.
			System.out.println("Enter the amount to be deposited");
			depositAmt1 = sc1.nextInt();
		} while(depositAmt1 < minbal);   // The condition is given inside the while keyword.
		balance1 = depositAmt1;
		System.out.println("Your deposit was successful");

		 */




	}
}
