
public class O_VariableArguments {

	static void display(String...values) {
		System.out.println("Inside Static Method");


		for(String s:values) {
			System.out.println(s);
		}
	}


	void display(int accountId, int... amount){
		int sum=0;
		for(int x:amount){
			sum+=x;
		}
		System.out.println("The sum is: "+accountId+sum);
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//display();
		//display("1","2","3");
		//display("Hello","Ronak");

		O_VariableArguments account = new O_VariableArguments();
		account.display(1001, 20,30,40,60,80);
		System.out.println("Main method over");

	}

}



