enum Designation{
	CEO(2),GeneralManager(4),RegionalManager(20),BranchManager(30);

	private int noofEmployees;
	Designation(int noofEmployees) {
		this.noofEmployees=noofEmployees;
	}

	public int getNoofEmployees(){
		return noofEmployees;
	}
}


public class P_Enum {

	enum Flavor{
		CHOCOLATE, VALINA, STRAWABERRY;
	}

	public void reportees(Designation designation) {
		System.out.println(designation.getNoofEmployees());
	}

	public static void main(String[] args) {

		P_Enum bank = new P_Enum();
		bank.reportees(Designation.CEO);


		levels l = levels.Low;
		System.out.println(l);

		Flavor flav = Flavor.VALINA;
		if(flav == flav.VALINA) {

			System.out.println("It is valina");

		}

		for (levels i:levels.values()) {
			System.out.println(i);
		}
	}
}

enum levels {
	Low,Medium,High;
}




//////////////////////////


enum Branches {

	Delhi(2),Chennai(3),Mumbai(3),Bangalore(5);
	
	private int noofOffice;
	
	private Branches(int noofOffice){
		this.noofOffice=noofOffice;
	}
	
	public int getNoofOffice(){
		return noofOffice;
	}
}
class TestEnum{
	public static void main(String[] args) {
		System.out.println(Branches.Bangalore.getNoofOffice());
	}
}





