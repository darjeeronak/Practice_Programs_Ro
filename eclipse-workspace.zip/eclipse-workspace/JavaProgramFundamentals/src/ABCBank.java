
public class ABCBank {

	public static void main(String args[]){


		/*
		System.out.println("Hello World");

		int a = 5;
		int b = 5;

		System.out.println(a == b);


		if ( a > 1 && b > 1)  {
			System.out.println("Hello");
		}


		/*int m = 1;

		//System.out.println(m++ + ++m);

		m=2;
		//System.out.println(++m + m++);

		System.out.print("++m : ");
		System.out.print(++m);

		System.out.println("");
		//System.out.println(++m + m++);
		m=2;
		System.out.println(m);

		System.out.print("m++ : ");
		System.out.print(m++);

		m = 1;
		int n = ++m + m++ + --m;
		System.out.println(n);  


		 */



		int a1=5,i=0;
		i=++a1 + ++a1 + a1++;

		System.out.println(a1);
		System.out.println(i);

		System.out.println();

		a1=5;
		i=0;

		i=a1++ + ++a1 + ++a1;

		System.out.println(a1);
		System.out.println(i);


		a1=++a1 + ++a1 + a1++;



		//System.out.println(m--);
		//System.out.println(--m);

	}
}