
public class R_Interfaces {

}

interface I1{
	void show();

}


interface I2{
	void display();

}

class Testtest implements I1,I2
{
	public void show() {
		System.out.println("1");
	}

	public void display() {
		System.out.println("2");
	}

	public static void main(String[] args) {
		Testtest t = new Testtest();
		t.show();
		t.display();
	}
}