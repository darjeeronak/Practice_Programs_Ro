import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class U_Date {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate date = LocalDate.now();

		System.out.println(date);



		Date startUtilDate = new Date();
		// Assume that the obtained date is Thu Nov 03 20:40:45 IST 2016
		Date tempUtilDate = startUtilDate;
		startUtilDate.setDate(26);
		System.out.println(tempUtilDate);

		LocalDate startLocalDate = LocalDate.of(2016, Month.JUNE, 01);
		LocalDate tempLocalDate = startLocalDate;
		startLocalDate = startLocalDate.plusDays(10);
		System.out.println(tempLocalDate);





		LocalDate paySlipDate = LocalDate.now();
		System.out.println(paySlipDate);                                             // Output: 2016-11-21
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MMM/yyyy");
		System.out.println(paySlipDate.format(formatter));    


		System.out.println("ZonedDateTime Now: "+ZonedDateTime.now());    



		Date date1 = new Date();
		System.out.println(date1.toString());
		System.out.println(date1.getTime());

		System.out.println(1+ date1.getMonth());
		System.out.println(1900+date1.getYear());
		System.out.println(date1.getDay());
		System.out.println(date1.getHours());


		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		System.out.println(sdf.format(date));

	}

}



class AdvanceSalary {
	private LocalDate from;
	private LocalDate to;

	public AdvanceSalary(LocalDate from,LocalDate to) {
		this.from = from;
		this.to = to;
	}

	public void checkDates() {
		int compare = from.compareTo(to);
		System.out.println(compare);
		// Logic that makes sure from is not greater than to
	}
}

class TechSol  {
	public static void main(String[] args) {
		LocalDate from = LocalDate.of(2016, Month.JUNE, 01);
		LocalDate to = LocalDate.of(2016, Month.JUNE, 03);
		AdvanceSalary advance = new AdvanceSalary(from, to);
		advance.checkDates();
	}
}