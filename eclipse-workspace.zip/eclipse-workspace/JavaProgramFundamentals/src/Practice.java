/*
public class Practice {



	public void display(Object ref){
		System.out.println("Object..."+ref);
	}

	public void display(String ref){
		System.out.println("String..."+ref);
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Practice abc = new Practice();
		abc.display(null);


	}

}




 */






class Person${
	String name;
	Person$(){
		name="John";
		System.out.println("In Person: Parent Class");
	}

	public void getDetails(){
		System.out.println(name);
	}
}

class Employee$ extends Person${
	int age;
	Employee$(){
		age=34;
		System.out.println("In Employee: First Child Class");
	}
	public void getDetails(){
		System.out.println(name+age);
	}
}

class Customer$ extends Employee${
	int salary;
	Customer$(int salary){
		this.salary=salary;
		name="Maddy";
		System.out.println("In Employee: Second Child Class");
	}

	public void getDetails(){
		System.out.println(name+age+salary);
	}
}

class Account$ {
	public static void main(String[] args) {
		Person$ c=new Customer$(20000);
		c.getDetails();
	}
}




