
public class H_ThisKeyword {

	private String bankName; //instance variable
	private String area; 
	private String phoneNumber; 

	int i;
	H_ThisKeyword (int i){
		System.out.println(i);
		this.i=i;
	}


	H_ThisKeyword(String bankName, String area, String phoneNumber) { // Parameterized constructor 

		this.bankName = bankName;   //this keyword is used to assign
		this.area = area;           //the value for instance variables
		this.phoneNumber = phoneNumber; 

	} 

	void displayBankDetails(){ 
		System.out.println("Bank Name: " + bankName); 
		System.out.println("Area of bank: " + area); 
		System.out.println("Phone number of bank: " + phoneNumber); 

	} 

	public static void main(String[] args) {




		H_ThisKeyword obj = new H_ThisKeyword(10);
		System.out.println(obj.i);






		H_ThisKeyword bank = new H_ThisKeyword("IBank", "Jaydev Nagar", "8876543210");
		bank.displayBankDetails();

	}

}
