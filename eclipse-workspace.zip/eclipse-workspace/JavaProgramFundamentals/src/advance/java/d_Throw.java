package advance.java;

public class d_Throw {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=100,b=10,c;

		c=a/b;
		System.out.println(c);

		try {
			if (c>1){
				System.out.println("Hello");
				throw new RonakException("Something is wrong Sir  ");
			}
		}
		catch(RonakException e) {
			e.printStackTrace();
		}

		System.out.println("Code ran successfully !! ");
	}
}



class RonakException extends RuntimeException
{

	RonakException(String abc)
	{
		super(abc);
	}

}