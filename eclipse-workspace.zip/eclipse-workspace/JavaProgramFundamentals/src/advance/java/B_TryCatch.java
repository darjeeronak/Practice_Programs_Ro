package advance.java;
import java.io.FileInputStream;

public class B_TryCatch {

	public static void main(String[] args) {


		try {
			FileInputStream fis = new FileInputStream("d:/abc.txt");
		}

		catch(Exception e)
		{
			System.out.println("File not founf");
		}

		try {
			int a = 100, b= 0,c;
			c = a/b;
			System.out.println(c);
		}
		catch(ArithmeticException e ){
			System.out.println("You cannot divide by 0 ");
		}
		catch(Exception e) {
			System.out.println("Heya");
		}


		try {

			String name=null;
			System.out.println(name.length());
			System.out.println("In try block");
		}

		finally{
			System.out.println("I am in finally block");
		}

		System.out.println("Outside try block");
	}

}
