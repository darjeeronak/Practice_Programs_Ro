
package advance.java;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.time.LocalDate;


public class e_throws {

	void readfile() throws FileNotFoundException {
		FileInputStream fis = new FileInputStream("d:/abc.txt");
	}


	public static void main(String[] args) {
		e_throws rw= new e_throws();

		try {
			rw.readfile();
		}
		catch(FileNotFoundException e){
			e.printStackTrace();
			System.out.println("Hello");
		}

	}	
}
















class Fruits {
	protected Fruits(){        // Line 3
		System.out.println("heya");
	}
}

class mango extends Fruits {

	public static void main(String[] args){
		Fruits f = new Fruits();

		LocalDate date = LocalDate.of(12,11,2017);
		System.out.println(date);

		String a= "abc";
		switch (a) {
		case 23:
			break;
		case "hello"
		break;

		case "abc"
		break;

		default:
			break;
		}

	}
}



class TestDemo {
	private static Object staticObject;
	public static Object createStaticObject(){
		if(staticObject == null){
			staticObject = new Object();
		}
		return staticObject;
	}
}