package advance.java;

public class C_Final_Finally_Finalize {

	final int a = 10;
	final void show() {
		System.out.println("This method will not override");
	}

	final class test{
		private void syso() {
			System.out.println("cannot be inherit ie extend wont work");
		}
	}


	protected void finalize() throws Throwable{
		System.out.println("Run before GC");
	}

	public static 
	void main(String[] args) {
		// TODO Auto-generated method stub

		try {}
		catch(Exception e){}
		finally {}
	}

}
