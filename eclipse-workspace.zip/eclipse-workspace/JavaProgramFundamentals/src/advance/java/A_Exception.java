package advance.java;

import java.io.FileInputStream;

public class A_Exception {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(1);
		System.out.println(2);
		System.out.println(3);
		System.out.println(4);
		//System.out.println(100/0); //Exception thrown here and flow further doesnt go - run time exception
		System.out.println(5);
		System.out.println(6);
		System.out.println(7);
		System.out.println(8);
		System.out.println(9);


		try {
			Class.forName("com.mysql.jdbc.Driver");  // compile time exception
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}


		try {
			//FileInputStream fis = new FileInputStream("d:/abc.text");
		}
		catch(Exception e)
		{
			System.out.println("File Not Found");
		}
	}

}
