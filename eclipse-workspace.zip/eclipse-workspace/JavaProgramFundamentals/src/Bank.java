
public class Bank {

	String bankName, area, phoneNo;


	//bank(){
	//		System.out.println();
	//}
	void Bank() {

	}
	Bank(){
		bankName = "abc";
	}

	public static void main(String[] args) {

		Bank bank = new Bank();

		System.out.println(bank.bankName);
	}

}
