
public class D_Implicit_Explicit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double d = 234.04;
		long l = (long)d;   //explicit type casting
		int i = (int)l;     // explicit type casting
		System.out.println("double value :"+d);
		System.out.println("long value :"+l);
		System.out.println("int value :"+i);



		int i1 = 300;
		long l1 = i1;       //no explicit type casting
		float f = l1;     //no explicit type casting
		System.out.println("int value :"+i1);
		System.out.println("long value :"+l1);
		System.out.println("float value :"+f);

		D_Implicit_Explicit bank = new D_Implicit_Explicit();
		System.out.print(bank.getPhone());

		//long x = 88843.78; // Line 1
		float x = 0;
		float y= x; //Line 2
		double z=x+y; //Line 3
		System.out.println(z);


		int anc = 1;
		float anc1 = anc;

		float anc2 = 1;
		int anc3 =  (int) anc2;

		double price=30.0f;

		float price1=(float) 30.0d;






		byte b = 50; //Line 1
		b = (byte) (b * 50);//Line 2
		System.out.println(b);    
	}


	double methodA(byte x, double y) //line2
	{  
		return (short)x / y * 2;
	}




	int phone=312345;
	double getPhone(){
		System.out.print("phone number received");
		return phone;
	}


}




