package practice_ron;

public class practice2 {

	public static void main(String[] args) {
		char a= 'a';

		switch(a) {

		case 65:
			System.out.println("Check");
			break;

		case 450:
			System.out.println("Check2");
			break;

		case 'a':
			System.out.println("Check3");
			break;
		default:
			System.out.println("haaha");
			break;
		}


	}

}
