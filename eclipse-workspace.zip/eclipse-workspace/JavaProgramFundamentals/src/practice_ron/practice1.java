package practice_ron;

public class practice1 {



	public static void main(String[] args) {

		int x,y,z;
		x=10; y =20;
		z* = ++x + ++y + x++ + y ++; //error here

		System.out.println(z);

	}

}