public class F_Arrays {


	public static void main(String[] args) {

		int[] value = new int[3];
		value[0] = 100;
		value[1] = 200;
		value[2] = 300;

		for ( int i=0; i < value.length; i++) {
			System.out.println(value[i]);
		}


		int marks[] = new int[3];
		int[] marks1 = new int[3];


		int marks11[][] = new int[2][3];


		int[] az = new int[3];
		int az1[] = new int[5];
		int az2[][] = new int [3][2];


		Customer customer[] = new Customer[2]; //Reference type Array
		Customer customer1 = new Customer("Anil", "Acc12345");
		Customer customer2 = new Customer("Ajay", "Acc12346");
		customer[0] = customer1; //storing in the array
		customer[1] = customer2;

		for(int i=0;i<customer.length;i++){ //traversing the array
			Customer customeObject = customer[i]; //retrieving customer Object
			String name = customeObject.displayCustomerName();
			System.out.println("the customer name is..."+name);
		}





		int myArr[] = new int[] {0 , 1, 2, 3, 4, 5, 6, 7, 8, 9};
		int n = 6;
		n = myArr[myArr[n] / 2];
		System.out.println(myArr[n] / 2);


		double salary[] = {23500.0, 25080.0, 28760.0, 22340.0, 19890.0};
		double totalsum = 0;
		int totalcount =  salary.length;

		for ( int i=0; i <totalcount ; i++) {
			totalsum = totalsum + salary[i];
		}

		double avgsal = (totalsum/totalcount);

		System.out.println("Average Salary is : " +avgsal );


		int counter1 = 0;
		int counter2 = 0;

		for ( int i=0; i <totalcount ; i++) {

			if ( salary[i] > avgsal) {
				counter1++;
			}

			if ( salary[i] < avgsal) {
				counter2++;
			}
		}


		System.out.println("Average Salary more  : " +counter1 );
		System.out.println("Average Salary less : " +counter2 );



		int arrr[] = {1,2,3,4,5,6,7,8,9,10,11,12};

		for (int i :arrr) {
			System.out.println("No " +i +" : "+arrr[i-1]);
		}


		int arrr1[] = {11,12,13,14,15};

		for (float i :arrr1) {
			System.out.println("No: " +i );
		}



	}

}


class Customer{
	private String name;
	private String customerId;

	Customer(String abcd1, String abcd2){
		name = abcd1;
		customerId = abcd2;
	}

	public String displayCustomerName(){
		return name;
	}
}

