
public class a_HelloWorld {


	private double balance = 500.00;  // member data
	public double  getBalance(int x) {     // member method
		// logic here
		return balance;
	}


	public static void main(String[] args) {
		System.out.println("Hello World");

		a_HelloWorld accnt = new a_HelloWorld();            // object creation
		double value = accnt.getBalance(123456);
		System.out.println("The balance is: " + value);
	}

}
