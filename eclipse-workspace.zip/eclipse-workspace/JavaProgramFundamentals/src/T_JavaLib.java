
public class T_JavaLib {



	public void checkUsername(String name){

		String username="infosys";

		if(name.equals(username)){
			System.out.println("valid1"); 
		}
		if(name==username){
			System.out.println("valid2"); 
		}
		if(name.equals(new String("infosys"))){
			System.out.println("valid3"); 
		}
		if(name==new String("infosys")){
			System.out.println("valid4");
		}
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new T_JavaLib().checkUsername("infosys");//Line 1



		int ab = 12321;
		String abcd = Integer.toString(ab);


		StringBuilder rev = new StringBuilder(abcd);
		String xyz = rev.reverse().toString();

		if ( abcd.equals(xyz)) {
			System.out.println("Number is Palindrome");
		}
	}

}
