
class Person{

	String name;
	Person(){
		name="John";
	}
}


class Employee extends Person{
	int age;
	Employee(){
		age=34;
	}
}


class Cust extends Person{
	int salary;

	Cust(int salary){
		this.salary=salary;
		name="Maddy";
	}

	public void displayDetails(){
		//		System.out.println(name+age+salary);

		System.out.println(name+salary);

	}
}

class Account {
	public static void main(String[] args) {
		Cust c=new Cust(20000);
		c.displayDetails();
	}
}