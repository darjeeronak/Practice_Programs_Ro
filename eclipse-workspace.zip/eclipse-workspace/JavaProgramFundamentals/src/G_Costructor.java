
public class G_Costructor {

	private String bankName, area;
	private String phoneNumber;

	G_Costructor(){  // Default constructor
		bankName = "IBank";
		area = "Gandhi Nagar";
		phoneNumber = "9876543210";
	}

	G_Costructor(String bname, String barea, String phoneNo) {  // Parameterized constructor
		bankName = bname;
		area = barea;
		phoneNumber = phoneNo;
	}

	void displayBankDetails(){
		System.out.println("Bank Name: " + bankName);
		System.out.println("Area of bank: " + area);
		System.out.println("Phone number of bank: " + phoneNumber);
	}


	String bankName1, area1, phoneNo1;

	public static void main(String[] args) {

		G_Costructor bank1 = new G_Costructor();
		G_Costructor bank2 = new G_Costructor("IBank", "Jaydev Nagar", "8876543219");

		bank1.displayBankDetails();
		System.out.println();
		bank2.displayBankDetails();


		G_Costructor bank3 = new G_Costructor();
		System.out.println("");
		System.out.println("No Name:");
		System.out.println(bank3.bankName1);

	}









}
