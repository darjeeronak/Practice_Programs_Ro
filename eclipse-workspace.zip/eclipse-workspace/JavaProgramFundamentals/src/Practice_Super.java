
public class Practice_Super {

	//Practice_Super(){
	//	System.out.println("Request for loan");
	//}

	Practice_Super(int x){
		System.out.println("Request for Loan");
	}

}


class Child_Practice_Super extends Practice_Super{

	Child_Practice_Super(){
		super(1);
		System.out.println("Request for HomeLoan");
	}


	public static void main(String[] args) {

		Child_Practice_Super obh = new Child_Practice_Super();

	}
}