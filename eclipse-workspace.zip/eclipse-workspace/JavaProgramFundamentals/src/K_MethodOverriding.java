public class K_MethodOverriding {

	public double calculateEMI(double principal){
		double simpleInterest = (principal * 8.5 * 5) / 100;
		double emi = (simpleInterest + principal) / 5;
		System.out.println("In Parent Class_1");

		return emi;

	}
}


class HomeLoan_1 extends K_MethodOverriding {
	// method overriden
	public double calculateEMI(double principal){
		int additionalTax = 200;
		double simpleInterest = (principal * 7.5 * 20) / 100;
		double emi = (simpleInterest + principal) / 20;
		System.out.println("In Child Class_1A : HomeLoan_1 ");

		return emi+additionalTax;
	}
}

class VehicleLoan_1 extends K_MethodOverriding {
	// method overriden
	public double calculateEMI(double principal){
		int additionalTax = 200;
		double simpleInterest = (principal * 9.5 * 10) / 100;
		double emi = (simpleInterest + principal) / 10;
		System.out.println("In Child Class_1B : VehicleLoan_1 ");

		return emi+additionalTax;
	}
}


class ExecuteLoan{
	public static void main(String[] args){


		K_MethodOverriding loan = null;
		loan = new HomeLoan_1();      //Runtime Polymorphism

		double hloan = loan.calculateEMI(2000000);

		loan = new VehicleLoan_1();   //sup class reference holding sub class Object
		double vloan = loan.calculateEMI(100000);
		System.out.println("Home loan emi per year is..." + hloan);
		System.out.println("Vehicle loan emi per year is..." + vloan);

	}
}