class N_Static {


	static int minbalance;
	int abc;

	static{
		minbalance = 500;
		abc = 100; // cant use this

	}

	public static int getMinimumBalance(){
		return minbalance;
	}


	void men() {
		System.out.println(minbalance);
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("The value.." + getMinimumBalance());
		System.out.println(minbalance);
		System.out.println(N_Static.minbalance);

		N_Static test = new N_Static();
		test.getMinimumBalance();

	}

}
