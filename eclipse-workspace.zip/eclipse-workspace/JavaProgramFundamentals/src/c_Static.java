// before 1.6  version it works without main
// we have to create main method after 1.6 

public class c_Static {

	static {
		System.out.println("Static Block");
	}


	public static void main(String[] args) {
		System.out.println("Inside Main Method");
	}

}
