package restassuredTests;

import java.util.HashMap;
import org.testng.annotations.BeforeClass;
import io.restassured.RestAssured;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;




public class Demo3_PUT_Request {

	public static HashMap map1 = new HashMap();
	int id = 12432;

	@BeforeClass
	public void putData() {

		map1.put("name","Ronak");
		map1.put("salary","123");
		map1.put("age","26");

		RestAssured.baseURI="http://dummy.restapiexample.com/public/api/v1";
		RestAssured.basePath="/update/"+id;
	}

	@Test
	public void testPUT() {

		given()
			.contentType("application/json")
			.body(map1);

		when()
			.put()

		.then()
			.statusCode(200)
		.and()
			.body(containsString("success"))
		.and()
			.body(containsString("Successfully! Record has been updated."))
			.log().all();

	}

}
