package restassuredTests;

import org.apache.commons.lang3.RandomStringUtils;

public class RestUtils {

	public static String getName() {
		String generatedString = RandomStringUtils.randomAlphabetic(1);
		return("test"+generatedString);
	}


	public static String getSalary() {
		String generatedString = RandomStringUtils.randomNumeric(3);
		return(generatedString);
	}


	public static String getAge() {
		String generatedString = RandomStringUtils.randomNumeric(3);
		return(generatedString);
	}


}
