package restassuredTests;


import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
//import static org.hamcrest.Matchers.*;
import java.util.HashMap;

import org.testng.annotations.BeforeClass;
import io.restassured.RestAssured;
import io.restassured.matcher.ResponseAwareMatcher;
import io.restassured.response.Response;

import static org.hamcrest.CoreMatchers.*;

import org.hamcrest.CoreMatchers;
import org.hamcrest.CoreMatchers.*;
import org.hamcrest.Matchers;




public class Demo2_POST_Request {

	public static HashMap map = new HashMap();

	@BeforeClass
	public void postdata(){

		map.put("name",RestUtils.getName());
		map.put("salary",RestUtils.getSalary());
		map.put("age",RestUtils.getAge());

		RestAssured.baseURI="http://dummy.restapiexample.com/api/v1";
		RestAssured.basePath="/create";

	}

	@Test
	public void testPost() {

		given()
			.contentType("application/json")
			.body(map)

		.when()
			.post()

		.then()
			.statusCode(200)
		.and()
		//.body("status", equalTo("success"))
		.body(containsString("success"))
		.and()
		//.body("message", CoreMatchers.equalTo((Object)"Successfully! Record has been added."))
		//.body("message", equalTo(Integer.valueOf("Successfully! Record has been added.").toString()));
		.body(containsString("Successfully! Record has been added."));

	}


}