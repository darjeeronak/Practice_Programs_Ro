package restassuredTests;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.Matchers.equalTo;


public class Demo5_BasicValidations {


	//Test StatusCode

	@Test(priority=1)
	public void testStatusCode() {
		//given()
		when()
		.get("https://jsonplaceholder.typicode.com/posts/1")

		.then()
		.statusCode(200);
		//.log().all();
	}


	// Log Request
	@Test(priority = 2)
	public void testLogging() {
		
		given()
		
		.when()
			.get("http://dummy.restapiexample.com/api/v1/employee/1")

		.then()
			.statusCode(200)
			.log().all();
	}


	// Verifying Single content
	@Test(priority = 3)
	public void testSingleContent() {
		
		given()
		
		.when()
			.get("http://dummy.restapiexample.com/api/v1/employee/1")

		.then()
			.statusCode(200)
			//.body("data.employee_name", equalTo("Tiger Nixon"));
			.body(containsString("Tiger Nixon"));
					
	}
	
	
	@Test(priority = 4)
	public void testMultipleContent() {
		
		given()
		
		.when()
			.get("http://dummy.restapiexample.com/api/v1/employees")

		.then()
			.statusCode(200)
			.body("data.employee_name", equalTo("Tiger Nixon"));
			
			
					
	}
	
	
}
