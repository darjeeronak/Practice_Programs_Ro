package restassuredTests;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;


//import org.testng.annotations.*;


public class Demo1_GET_Request {

	@Test
	public void GET_Request() {
		System.out.println("Test: Into Get Request");


		
		given()
	
	
		.when()
			.get("http://dummy.restapiexample.com/api/v1/employee/1")
			
		.then()
			.statusCode(200)
			.header("Content-Type", "application/json")
			//.header("Date","Tue, 06 Oct 2020 04:16:27 GMT")
			//.assertThat().body("message", equalTo("Successfully! Record has been fetched."))
			.assertThat().body(containsString("Successfully! Record has been fetched."));
		
	}
}