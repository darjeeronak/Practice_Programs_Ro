package restassuredTests;

import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;


public class Demo4_DELETE_Request {

	@Test
	public void deleteEmployeeRecord()
	{

		RestAssured.baseURI="http://dummy.restapiexample.com/public/api/v1";
		RestAssured.basePath="delete/2";

		Response response =
				
			given()
	
			.when()
				.delete()
	
			.then()
				.statusCode(200)
				.statusLine("HTTP/1.1 200 OK")
				.log().all()
				.extract().response();
		
		String jsonString = response.asString();
		Assert.assertEquals(jsonString.contains("Successfully! Record has been deleted"),true);
		

	}
}
